create definer = root@localhost event update_client_status on schedule
    every '1' MINUTE
        starts '2025-12-31 16:53:43'
    enable
    do
    BEGIN
    -- Mark clients as offline if no heartbeat in 2 minutes
    UPDATE clients
    SET status = 'offline'
    WHERE last_heartbeat < DATE_SUB(NOW(), INTERVAL 2 MINUTE)
      AND status = 'online';
END;

